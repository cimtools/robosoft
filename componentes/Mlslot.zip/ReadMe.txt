-----------------------------------------------------------------

                         TmdMailSlot

-----------------------------------------------------------------

The inhand package is in version 1.13, and given free the
2nd January 1999.

Latest version will always be avalible from
http://www.djernaes.dk/martin

The Package gives three classes (two components) to use within
the Delphi 2.0, 3.0 and C++ Builder enviroment.

1.13 : Corrected a binary problem with the receiver object for
LongMail. Thanks to Rafe Aldridge for pointing me to the problem.

1.12 : Corrected a binary problem with SendBufSecure - Thanks
to Richard Kable.
Removed all outcommented code - if you want old code, then send
me a mail.
Bether support for binary messages are added in the base component.
Some new components are added with enhanged or new functionallity!
- TmdSafeMail is basically the same as TmdSecureMail, but the
  format is different
- TmdLongMail is a new component takeing care of splitting
  your message into segments, and collecting them again
  when receiving messages. (max. message size with LongMail is
  65533 bytes)

1.11 : The in version 1.10 improovment did unfortunately not
work on Win95, so the wait thread is now back to it's old
state for Windows 95 but under Windows NT it still use less
resources.
Sascha Buchner Pointed out a missing correction in the function
SendBufSecure - Thanks.
Removed values which were conflicting with teh new D4 type DWord.

1.10 : The Wait Thread do not poll on the mailslot anylonger,
but uses a read of zero bytes, which returns when there is
data in the mailslot. This result in less used CPU resources
by the Wait Thread.

1.9 : In this version a problem with random values bigger than
$80000000 solved (Thanks to Raoul De Kezel for telleing me about
the problem).

1.8 : Thanks to Alek Shamrai a working version of the new
TmdCustomWinPopup component can be released.

1.7 : The Thread which waits for messages is updatet, so Threads 
is freed nicely up by close of the mailslot.
Also is added a functionallity which should ignore dublicated 
WinPopup messages to the TmdCustomWinPopup component.

1.5 : The last time quite a lot of people have asked me why 
they get duplicated messages from a mailslot. The reason is that 
a mailslot message is send via all availible transport layers on
the network (meaning that if you have more than one protocol
installed on the sending computer, which also is installed on the
receiving computer, you will get duplicates of the message).
This is the reason that I have created my new secure mailslot
component. The component add a preample (4 chars), which is used
to make the message as close to unique as possible, and a CRC16
(4 chars) for preventing messages with errors in sending out
a OnMessage event.
You should notice that the TmdWinPopup component is unchanged,
since it has to be compatible with WinPopup !

-----------------------------------------------------------------
Mini FAQ:

Q: Why can't I send more that 420 bytes between two Win95
   machines on my network.?
A: As far as I know there should be a but in the Win95/98
   NetBios interface makeing 420 (or is it 423) bytes the
   maximum message size.

Q: Why can WinPopup send longer messages that 420 bytes from
   one Win95 machine to another, when I can't?
A: This is because WinPopup do NOT use mailslots for sending
   and receiving messages over the network. Mailslots is "just"
   a shortcut to send/receive messages.

Q: Why do I not receive a message via the network, when I do
   on the Local machine?
A: If you a using Windows 95 machines in your network (and I
   guess 98 as well), you must notice that you will have to
   conform to the old 8.3 filename format.
   Mailslots can normally be longer that 8.3, but because of
   a bug in the Win32 which Windows 95 is based on, the 
   filenames will be truncated into 8.3 conform names.
   See Article ID: Q139716 in MSDN.

Q: Why do I receive several dublicated messages via a mailslot?
A: Because MailSlots is a unreliable broardcast service, which
   do not know about how to reach a receiver, it send all over.
   See Article ID: Q127905 in MSDN.

Q: Can I also use TmdWinPopup on a Windows NT machine?
A: Yes you can, but you must stop the Messenger service, since
   is using some of the resources which TmdWinPopup need.

Q: Why can I not send a message to a user when WinPoup can?
A: The reason for this is that WinPopup do actually not use
   mailslots for sending message, but direct NetBIOS calls.
   The mailslot interface to send messages, is a "easy interface"
   from Microsoft.
   The only small problem with using TmdMailSlot on NT, is
   that messages send via "NET SEND" or WinPopup do not end
   at the messngr mailslot (which is the case for Windows 95)
   because of NT removing the NetBIOS names used for the
   messenger communication, when stopping the messenger service.

-----------------------------------------------------------------
Components :
* TmdCustomMailSlot
  TmdMailSlot
* TmdAutoMailSlot  - Not relevant any longer (see source)
* TmdCustomWinPopup
  TmdWinPopup
* TmdCustomSecureMail
  TmdSecureMail
* TmdCustomNoErrMail
* TmdNoErrMail
* TmdCustomSafeMail
  TmdSafeMail
* TmdCustomLongMail
  TmdLongMail
*) Is not exported as component to Delphi

TmdCustomMailSlot :
  This is the base class containing all the mailslot functionallity
  given.

TmdMailSlot :
  This is the basic mailslot component, with the properties published.

TmdAutoMailSlot :
  This class in only included for compatibility with verions 1.0 of
  the package.

TmdCustomWinPopup :
  A class derived from TCustomMailSlot, build around the mailslot
  "messngr". The calss have the ability to recieve and send messages
  like WinPopup messages.

TmdWinPopup :
  This is the WinPopup cmpatible component with events from
  TmdCustomWinPopup published.

TmdCustomSecureMail :
  This class is based on the TmdCustomMailSlot, and do self remove 
  duplicated messages which may come because of availability of
  more than one transport layer in the network (more than one 
  protocol).
  The component have also got a CRC16 added to the message, so
  now it is also trying to prevent that a "broken" message is 
  arriving.
  This component also offer to new events, one inform about
  a wrong message (hole message including preample and CRC16 
  is passed as parameter) and a notification about a duplicate
  is detected.

TmdSecureMail :
  This component is the "public" version of TmdCustomSecureMail,
  and make all avalible properties published.

TmdCustomNoErrMail :
  This class is sending/receiving messages with a 16 bit binary CRC
  inserted in front of the message.

TmdNoErrMail :
  This component is the "public" version of TmdCustomSecureMail,
  and make all avalible properties published.
  The component is not exported to Delphi!

TmdCustomSafeMail
  This component is based on TmdCustomNoErrMail, and offers excact
  the same functionallity as TmdCustomSecureMail, but is not useing
  a ASCII header for ID (and CRC), but binary values - this reduce
  the overhead to the half.

TmdSafeMail
  This component is the "public" version of TmdCustomSafeMail,
  and make all avalible properties published.

TmdCustomLongMail
  This component is based on TmdCustomNoErrMail, and is responsible 
  for receiving (and sending!) message segments, so we can send and
  receive messages longer than 400 bytes (also when the receiver is
  a domain).
  The component uses a 1 bit indication of the first segment, 15 bit
  identifier for identifying different messages, and a 16 bit length
  value for identifying each received segment.
  The component expect that all messages is received in the order
  that they are send - I do not know if that is guarantied by
  mailslots, but in test it works.

TmdLongMail
  This component is the "public" version of TmdCustomLongMail,
  and make all avalible properties published.

-----------------------------------------------------------------
Functions :
  SendToMailSlot
  SendBufToMailSlot
  SendToWinPopup
  SendSecureMail
  SendBufSecure
  SendBufNoErr
  SendNoErrMail
  SendBufSafe
  SendSafeMail
  SendBufLong
  SendLongMail

SendToMailSlot :
  This is a function which can send a message to a mailslot anywhere
  in the network.

SendBufToMailSlot :
  This is a function which send a buffer's contents to a mailslot
  anywhere in the network.

SendToWinPopup :
  Sends a message to the "messngr" mailslot - WinPopup
  receives messages from this mailslot.

SendSecureMail :
  This function send a message (string) to a secure mailslot.

SendBufSecure :
  This function send a buffer to a secure mailslot.

SendBufNoErr :
  This function sends binary data to a TmdNoErrMail component

SendNoErrMail :
  This function sends string data to a TmdNoErrMail component

SendBufSafe :
  This function sends binary data to a TmdSafeMail component

SendSafeMail :
  This function sends String data to a TmdSafeMail component

SendBufLong :
  This function sends binary data to a TmdLongMail component

SendLongMail :
  This function sends String data to a TmdLongMail component


-----------------------------------------------------------------
Note :
  There is different ways of specifying different servers, or groups
  of servers.

  The notation "." is the current server = the machine where the
  program runs.

  The notation "*" is the current domain = the domain on the network
  which the server (the machine where the program runs on) is pressent.

  The notation "XXX" is the machine with the name XXX.

* The next one I am not sure about, but try it and tell me if it
  were working.

  The notation "XXX*" is the domain with the name XXX.

-----------------------------------------------------------------
Thanks :
  Thanks to Don Hass for giving me information about WinPopup's
  mailslot.

  Thanks to Matt Behrens for suggesting how to reduce the need
  of process time.

  Thanks to Channing Corn & Gary Winslow for reminding of my own
  mistakes ;-)

  Thanks to Alexander Orlov for his comments / information in
  general, and for finding one sure error and preventing another.

  Thanks to David Novak for correction of the code.

  Thanks to Marian Maier for pointing out the missing free
  of the wait thread.

  Thanks to Alek Shamrai for pointing out my idiotic ignorance
  (to weak testing before release) and a speciallity of Win95 ;-(

  Thanks to Sascha Buchner for pointing out my missing correction

  Thanks to the people who have being asking and commenting on
  the "lack" of D4 compatibility.

-----------------------------------------------------------------
Legal issues :
Copyright � 1997-99 by Martin Djern�s <martin@djernaes.dk>

This software is provided as it is, without any kind of warranty
given. The auther can not be held responsible for any kind of
damage, problems etc. arised from using this product.

You may use this software in any kind of development, including
comercial, and redistribute it freely, under the following
restrictions :

1. The origin of this software may not be mispresented, you must
   not claim that you wrote the original software. If you use
   this software in any kind of product, it would be appreciated
   that there in a information box, or in the documentation would
   be an acknowledgmnent like this
          Parts Copyright � 1997-99 by Martin Djern�s

2. You may not have any income from distributing this source
   to other developers. When you use this product in a comercial
   package, the source may not be charged seperatly.

3. This notice may not be removed from the source, when distributing
   such. When distributing a comercial package, where the source
   also is avalible, this notice should also follow the package, even
   you choose not to make my source avalible.

                                                               - MD99